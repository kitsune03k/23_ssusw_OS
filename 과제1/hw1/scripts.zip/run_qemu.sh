cd $XV6
make qemu-nox QEMU=$QEMU
